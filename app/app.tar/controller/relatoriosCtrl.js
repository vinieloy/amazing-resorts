(function () {
  'use strict';

  angular
    .module('app')
    .controller('relatoriosCtrl', relatoriosCtrl);

  relatoriosCtrl.$inject = ['$window', '$mdToast'];

  function relatoriosCtrl($window, $mdToast) {

    var re = this;


  }
})();