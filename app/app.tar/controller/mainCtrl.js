(function () {
  'use strict';

  angular
    .module('app')
    .controller('mainCtrl', mainCtrl);

  mainCtrl.$inject = ['$window', '$mdToast'];

  function mainCtrl($window, $mdToast) {

    var mn = this;


  }
})();