var loginApp = angular.module('loginApp', ['ngMaterial']);

loginApp.constant("Api", {
  "url": "http://amazingresort.somee.com/api/",
  "LoginUsuario": "http://amazingresort.somee.com/api/Usuario/Login/"
});